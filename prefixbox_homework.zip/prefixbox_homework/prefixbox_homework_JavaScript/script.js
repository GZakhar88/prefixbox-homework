"use strict";

let radioButton = document.querySelector(".sale");
let itemList = document.getElementsByClassName("product");
let length = itemList.length;
let dropDownList = document.querySelector(".order");
let i, stop, run;
let price = (item) => {
  return parseInt(
    item.lastElementChild
      .querySelector(".product-price")
      .innerText.split("")
      .filter((e) => e.match(/[0-9]/gm))
      .join("")
  );
};
let productName = (item) => {
  return item
    .querySelector(".product-data")
    .querySelector(".product-name")
    .innerText.toLowerCase();
};

//---------------------------------------------- FILTER ----------------------------------------------//
function filterSale() {
  for (i = 0; i < itemList.length; i++) {
    itemList[i]
      .querySelector(".product-data")
      .querySelector(".product-old-price")
      ? (itemList[i].style.display = "inline-block")
      : (itemList[i].style.display = "none");
  }
}
function undoFilter() {
  for (i = 0; i < itemList.length; i++) {
    itemList[i].style.display = "inline-block";
  }
}

radioButton.onclick = () => {
  radioButton.checked ? filterSale() : undoFilter();
};

//---------------------------------------------- SORT ------------------------------------------------//
function priceAsc() {
  run = true;
  while (run) {
    run = false;
    for (i = 0; i < length - 1; i++) {
      stop = false;
      if (price(itemList[i]) > price(itemList[i + 1])) {
        stop = true;
        break;
      }
    }
    if (stop) {
      itemList[i].parentNode.insertBefore(itemList[i + 1], itemList[i]);
      run = true;
    }
  }
}

function priceDesc() {
  run = true;
  while (run) {
    run = false;
    for (i = 0; i < length - 1; i++) {
      stop = false;
      if (price(itemList[i]) < price(itemList[i + 1])) {
        stop = true;
        break;
      }
    }
    if (stop) {
      itemList[i].parentNode.insertBefore(itemList[i + 1], itemList[i]);
      run = true;
    }
  }
}

function abcAsc() {
  run = true;
  while (run) {
    run = false;
    for (i = 0; i < length - 1; i++) {
      stop = false;
      if (productName(itemList[i]) > productName(itemList[i + 1])) {
        stop = true;
        break;
      }
    }
    if (stop) {
      itemList[i].parentNode.insertBefore(itemList[i + 1], itemList[i]);
      run = true;
    }
  }
}

function abcDesc() {
  run = true;
  while (run) {
    run = false;
    for (i = 0; i < length - 1; i++) {
      stop = false;
      if (productName(itemList[i]) < productName(itemList[i + 1])) {
        stop = true;
        break;
      }
    }
    if (stop) {
      itemList[i].parentNode.insertBefore(itemList[i + 1], itemList[i]);
      run = true;
    }
  }
}

// EVENT HANDLER
dropDownList.addEventListener("change", (event) => {
  switch (event.target.value) {
    case "0":
      priceAsc();
      break;
    case "1":
      priceDesc();
      break;
    case "2":
      abcAsc();
      break;
    case "3":
      abcDesc();
      break;
    default:
      priceAsc();
      break;
  }
});
